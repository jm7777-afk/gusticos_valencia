-- ============================================
-- BASE DE DATOS GUSTICO'S - VERSIÓN COMPLETA
-- ============================================
DROP DATABASE IF EXISTS gusticos_db;
CREATE DATABASE gusticos_db;
USE gusticos_db;

-- ============================================
-- TABLA USUARIOS (ADMIN)
-- ============================================
CREATE TABLE usuarios (
    id_usuario INT PRIMARY KEY AUTO_INCREMENT,
    usuario VARCHAR(50) UNIQUE NOT NULL,
    contrasena VARCHAR(255) NOT NULL,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    rol ENUM('admin','editor') DEFAULT 'editor',
    activo BOOLEAN DEFAULT TRUE,
    ultimo_acceso DATETIME,
    creado TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- TABLA CLIENTES
-- ============================================
CREATE TABLE clientes (
    id_cliente INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    contrasena VARCHAR(255) NOT NULL,
    telefono VARCHAR(20),
    direccion TEXT,
    puntos INT DEFAULT 0,
    activo BOOLEAN DEFAULT TRUE,
    creado TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email (email)
);

-- ============================================
-- TABLA CATEGORIAS
-- ============================================
CREATE TABLE categorias (
    id_categoria INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(50) NOT NULL,
    icono VARCHAR(50),
    orden INT DEFAULT 0,
    activo BOOLEAN DEFAULT TRUE
);

-- ============================================
-- TABLA PRODUCTOS
-- ============================================
CREATE TABLE productos (
    id_producto INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT,
    precio DECIMAL(10,2) NOT NULL,
    id_categoria INT,
    stock INT DEFAULT 0,
    imagen VARCHAR(255),
    destacado BOOLEAN DEFAULT FALSE,
    activo BOOLEAN DEFAULT TRUE,
    creado TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_categoria) REFERENCES categorias(id_categoria),
    INDEX idx_stock (stock),
    INDEX idx_precio (precio)
);

-- ============================================
-- TABLA PROMOCIONES
-- ============================================
CREATE TABLE promociones (
    id_promocion INT PRIMARY KEY AUTO_INCREMENT,
    codigo VARCHAR(50) UNIQUE NOT NULL,
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT,
    tipo ENUM('porcentaje','fijo') DEFAULT 'porcentaje',
    valor DECIMAL(10,2) NOT NULL,
    fecha_inicio DATETIME NOT NULL,
    fecha_fin DATETIME NOT NULL,
    usos_maximos INT DEFAULT NULL,
    usos_actuales INT DEFAULT 0,
    activo BOOLEAN DEFAULT TRUE,
    creado TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_codigo (codigo),
    INDEX idx_fechas (fecha_inicio, fecha_fin)
);

-- ============================================
-- TABLA ZONAS_ENVIO
-- ============================================
CREATE TABLE zonas_envio (
    id_zona INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL,
    precio_envio DECIMAL(10,2) NOT NULL,
    activo BOOLEAN DEFAULT TRUE,
    orden INT DEFAULT 0
);

-- ============================================
-- TABLA PEDIDOS
-- ============================================
CREATE TABLE pedidos (
    id_pedido INT PRIMARY KEY AUTO_INCREMENT,
    numero_pedido VARCHAR(20) UNIQUE NOT NULL,
    id_cliente INT,
    nombre_cliente VARCHAR(100) NOT NULL,
    telefono_cliente VARCHAR(20) NOT NULL,
    email_cliente VARCHAR(100),
    direccion_entrega TEXT NOT NULL,
    ubicacion_maps VARCHAR(255),
    id_zona INT,
    costo_envio DECIMAL(10,2) DEFAULT 0,
    fecha_pedido TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    subtotal DECIMAL(10,2) NOT NULL,
    descuento DECIMAL(10,2) DEFAULT 0,
    total DECIMAL(10,2) NOT NULL,
    total_usd DECIMAL(10,2),
    tasa_bcv DECIMAL(10,2),
    metodo_pago ENUM('pago_movil','efectivo','multipago') DEFAULT 'efectivo',
    datos_pago TEXT,
    estado_pedido ENUM('recibido','preparando','listo','entregado','cancelado') DEFAULT 'recibido',
    notificado BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (id_cliente) REFERENCES clientes(id_cliente),
    FOREIGN KEY (id_zona) REFERENCES zonas_envio(id_zona),
    INDEX idx_numero (numero_pedido),
    INDEX idx_fecha (fecha_pedido),
    INDEX idx_estado (estado_pedido)
);

-- ============================================
-- TABLA DETALLE_PEDIDO
-- ============================================
CREATE TABLE detalle_pedido (
    id_detalle INT PRIMARY KEY AUTO_INCREMENT,
    id_pedido INT NOT NULL,
    id_producto INT NOT NULL,
    nombre_producto VARCHAR(100) NOT NULL,
    cantidad INT NOT NULL,
    precio_unitario DECIMAL(10,2) NOT NULL,
    subtotal DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (id_pedido) REFERENCES pedidos(id_pedido) ON DELETE CASCADE,
    FOREIGN KEY (id_producto) REFERENCES productos(id_producto)
);

-- ============================================
-- TABLA COMENTARIOS
-- ============================================
CREATE TABLE comentarios (
    id_comentario INT PRIMARY KEY AUTO_INCREMENT,
    id_cliente INT NOT NULL,
    cliente_nombre VARCHAR(100) NOT NULL,
    rating INT CHECK (rating >= 1 AND rating <= 5),
    comentario TEXT NOT NULL,
    estado ENUM('pendiente','aprobado','rechazado') DEFAULT 'pendiente',
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_cliente) REFERENCES clientes(id_cliente),
    INDEX idx_estado (estado),
    INDEX idx_fecha (fecha)
);

-- ============================================
-- TABLA CARRUSEL
-- ============================================
CREATE TABLE carrusel (
    id_item INT PRIMARY KEY AUTO_INCREMENT,
    titulo VARCHAR(200),
    subtitulo TEXT,
    imagen VARCHAR(255) NOT NULL,
    orden INT DEFAULT 0,
    link VARCHAR(255),
    activo BOOLEAN DEFAULT TRUE
);

-- ============================================
-- TABLA CONFIGURACION
-- ============================================
CREATE TABLE configuracion (
    id_config INT PRIMARY KEY AUTO_INCREMENT,
    clave VARCHAR(50) UNIQUE NOT NULL,
    valor TEXT NOT NULL,
    actualizado TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ============================================
-- DATOS INICIALES
-- ============================================
INSERT INTO usuarios (usuario, contrasena, nombre, rol) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrador', 'admin');

INSERT INTO categorias (nombre, icono, orden) VALUES
('Hamburguesas', '🍔', 1),
('Pizzas', '🍕', 2),
('Ensaladas', '🥗', 3),
('Postres', '🍰', 4),
('Bebidas', '🥤', 5);

INSERT INTO zonas_envio (nombre, precio_envio, orden) VALUES
('Zona Norte', 3.99, 1),
('Zona Sur', 5.99, 2),
('Zona Este', 4.50, 3),
('Zona Oeste', 6.50, 4);

INSERT INTO configuracion (clave, valor) VALUES
('tasa_bcv', '40.00'),
('whatsapp', '+584244179135'),
('email_negocio', 'pedidos@gusticos.com'),
('telefono_contacto', '0412-1234567'),
('direccion_empresa', 'Av. Principal, Local 123');

INSERT INTO productos (nombre, descripcion, precio, id_categoria, stock) VALUES
('Hamburguesa Clásica', 'Carne 100g, queso cheddar, lechuga, tomate', 12.99, 1, 50),
('Hamburguesa Doble', 'Doble carne, doble queso, bacon', 15.99, 1, 30),
('Pizza Margarita', 'Salsa de tomate, mozzarella, albahaca', 18.50, 2, 15),
('Pizza Pepperoni', 'Salsa de tomate, mozzarella, pepperoni', 21.00, 2, 12),
('Ensalada César', 'Lechuga, pollo, crutones, aderezo César', 9.99, 3, 20),
('Pastel de Chocolate', 'Porción de pastel de chocolate', 5.50, 4, 8),
('Refresco', 'Lata 355ml', 1.99, 5, 100);

INSERT INTO promociones (codigo, nombre, descripcion, tipo, valor, fecha_inicio, fecha_fin) VALUES
('BIENVENIDA10', '10% primera compra', 'Descuento para nuevos clientes', 'porcentaje', 10, NOW(), DATE_ADD(NOW(), INTERVAL 1 YEAR)),
('MARTES15', 'Martes de descuento', '15% off todos los martes', 'porcentaje', 15, NOW(), DATE_ADD(NOW(), INTERVAL 1 YEAR));